import React from "react";

export default function App() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-pink-200 to-pink-400 text-gray-900 flex flex-col">
      {/* Hero Section */}
      <header className="flex flex-col items-center justify-center text-center py-20 px-6">
        <h1 className="text-5xl font-extrabold mb-4 text-pink-800">
          Ely Gracias Cosméticos ✨
        </h1>
        <p className="text-lg max-w-2xl mb-6">
          Produtos de alta qualidade, sofisticação e inovação para realçar a sua
          beleza única.
        </p>
        <button className="bg-pink-700 text-white font-semibold px-6 py-3 rounded-2xl shadow-lg hover:scale-105 transition-transform">
          Conheça Nossa Coleção
        </button>
      </header>

      {/* Produtos em Destaque */}
      <section className="grid md:grid-cols-3 gap-8 px-10 md:px-20 py-16">
        <div className="bg-white text-gray-800 p-6 rounded-2xl shadow-lg hover:shadow-2xl transition">
          <h3 className="text-xl font-bold mb-2 text-pink-700">💄 Batons Premium</h3>
          <p>
            Longa duração, textura cremosa e cores marcantes para qualquer
            ocasião.
          </p>
        </div>
        <div className="bg-white text-gray-800 p-6 rounded-2xl shadow-lg hover:shadow-2xl transition">
          <h3 className="text-xl font-bold mb-2 text-pink-700">
            🌸 Perfumes Exclusivos
          </h3>
          <p>Aromas sofisticados que transmitem personalidade e elegância.</p>
        </div>
        <div className="bg-white text-gray-800 p-6 rounded-2xl shadow-lg hover:shadow-2xl transition">
          <h3 className="text-xl font-bold mb-2 text-pink-700">
            🧴 Skincare Avançado
          </h3>
          <p>
            Tratamento completo para uma pele saudável, radiante e bem cuidada.
          </p>
        </div>
      </section>

      {/* Depoimentos */}
      <section className="bg-pink-50 py-16 px-10 md:px-20 text-center">
        <h2 className="text-3xl font-bold mb-10 text-pink-800">
          Amado por milhares de clientes 💕
        </h2>
        <div className="grid md:grid-cols-3 gap-8">
          <div className="p-6 bg-white rounded-2xl shadow-md">
            <p className="italic mb-4">
              “Nunca encontrei um batom tão duradouro e confortável. Ely Gracias
              virou minha marca favorita!”
            </p>
            <h4 className="font-semibold text-pink-700">– Camila Andrade</h4>
          </div>
          <div className="p-6 bg-white rounded-2xl shadow-md">
            <p className="italic mb-4">
              “Os perfumes são únicos, sempre recebo elogios quando uso.”
            </p>
            <h4 className="font-semibold text-pink-700">– Fernanda Silva</h4>
          </div>
          <div className="p-6 bg-white rounded-2xl shadow-md">
            <p className="italic mb-4">
              “Minha pele nunca esteve tão hidratada, os cremes são sensacionais.”
            </p>
            <h4 className="font-semibold text-pink-700">– Juliana Costa</h4>
          </div>
        </div>
      </section>

      {/* Captura de Leads */}
      <section className="bg-white py-16 px-10 md:px-20 text-center">
        <h2 className="text-3xl font-bold mb-6 text-pink-800">
          Receba novidades e promoções exclusivas 🎁
        </h2>
        <form className="max-w-xl mx-auto flex flex-col md:flex-row gap-4">
          <input
            type="text"
            placeholder="Seu nome"
            className="flex-1 px-4 py-3 rounded-xl border border-gray-300 focus:outline-none focus:ring-2 focus:ring-pink-400"
          />
          <input
            type="email"
            placeholder="Seu e-mail"
            className="flex-1 px-4 py-3 rounded-xl border border-gray-300 focus:outline-none focus:ring-2 focus:ring-pink-400"
          />
          <button
            type="submit"
            className="bg-pink-700 text-white font-semibold px-6 py-3 rounded-xl shadow-lg hover:scale-105 transition-transform"
          >
            Quero Receber
          </button>
        </form>
      </section>

      {/* Call to Action */}
      <section className="bg-pink-700 py-16 text-center text-white">
        <h2 className="text-3xl font-bold mb-4">Sua Beleza Merece o Melhor</h2>
        <p className="mb-6">
          Descubra por que a Ely Gracias Cosméticos é referência em qualidade e
          inovação.
        </p>
        <button className="bg-white text-pink-700 font-semibold px-8 py-3 rounded-2xl shadow-lg hover:scale-105 transition-transform">
          Comprar Agora
        </button>
      </section>

      {/* Footer */}
      <footer className="py-6 text-center text-gray-700 text-sm bg-pink-200">
        © {new Date().getFullYear()} Ely Gracias Cosméticos. Todos os direitos
        reservados.
      </footer>
    </div>
  );
}